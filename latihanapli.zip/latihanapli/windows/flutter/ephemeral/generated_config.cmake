# Generated code do not commit.
file(TO_CMAKE_PATH "D:\\mobileflutter\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "D:\\xmobile\\latihanapli" PROJECT_DIR)

set(FLUTTER_VERSION "0.1.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=D:\\mobileflutter\\flutter"
  "PROJECT_DIR=D:\\xmobile\\latihanapli"
  "FLUTTER_ROOT=D:\\mobileflutter\\flutter"
  "FLUTTER_EPHEMERAL_DIR=D:\\xmobile\\latihanapli\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=D:\\xmobile\\latihanapli"
  "FLUTTER_TARGET=D:\\xmobile\\latihanapli\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9CVUlMRF9OQU1FPTAuMS4w,RkxVVFRFUl9CVUlMRF9OVU1CRVI9MQ==,RkxVVFRFUl9WRVJTSU9OPTMuNDcuMg==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049ZDNiMTRjODc2OQ==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049YTgwNGIyNjE2NA==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMy4y"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=D:\\xmobile\\latihanapli\\.dart_tool\\package_config.json"
)
