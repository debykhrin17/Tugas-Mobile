package com.example.latihanapli

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
